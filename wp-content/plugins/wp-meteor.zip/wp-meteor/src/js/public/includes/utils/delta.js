const initialTime = new Date();
export default () => (new Date() - initialTime) / 1000;

