import EventEmitter from '../../../common/event-emitter';
export default new EventEmitter();
